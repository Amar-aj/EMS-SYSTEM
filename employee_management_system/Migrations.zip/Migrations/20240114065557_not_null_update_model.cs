﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace employee_management_system.Migrations
{
    /// <inheritdoc />
    public partial class not_null_update_model : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
